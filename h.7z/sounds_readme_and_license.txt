Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by the following user:
 - ProjectsU012 ( https://www.freesound.org/people/ProjectsU012/ )

You can find this pack online at: /people/ProjectsU012/packs/18837/

License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 361018__projectsu012__warpappear1-chiptone.wav
    * url: https://www.freesound.org/s/361018/
    * license: Attribution
  * 361017__projectsu012__boom1.wav
    * url: https://www.freesound.org/s/361017/
    * license: Attribution
  * 361016__projectsu012__boom5.wav
    * url: https://www.freesound.org/s/361016/
    * license: Attribution
  * 361015__projectsu012__pwm-experiment-1.wav
    * url: https://www.freesound.org/s/361015/
    * license: Attribution
  * 361014__projectsu012__bga4.wav
    * url: https://www.freesound.org/s/361014/
    * license: Attribution
  * 361013__projectsu012__bobbing1-chiptone.wav
    * url: https://www.freesound.org/s/361013/
    * license: Attribution
  * 361012__projectsu012__bobbingsine-chiptone.wav
    * url: https://www.freesound.org/s/361012/
    * license: Attribution
  * 361011__projectsu012__arpeggtrickle1-chiptone.wav
    * url: https://www.freesound.org/s/361011/
    * license: Attribution
  * 361010__projectsu012__bassdrum2-sfxr.wav
    * url: https://www.freesound.org/s/361010/
    * license: Attribution
  * 361009__projectsu012__bga1.wav
    * url: https://www.freesound.org/s/361009/
    * license: Attribution
  * 361008__projectsu012__bga2.wav
    * url: https://www.freesound.org/s/361008/
    * license: Attribution
  * 361007__projectsu012__grab1.wav
    * url: https://www.freesound.org/s/361007/
    * license: Attribution
  * 361006__projectsu012__gradualsqueak1-chiptone.wav
    * url: https://www.freesound.org/s/361006/
    * license: Attribution
  * 361005__projectsu012__grappled1-chiptone.wav
    * url: https://www.freesound.org/s/361005/
    * license: Attribution
  * 361004__projectsu012__grapplepullup-chiptone.wav
    * url: https://www.freesound.org/s/361004/
    * license: Attribution
  * 361003__projectsu012__wobblingtonal-chiptone.wav
    * url: https://www.freesound.org/s/361003/
    * license: Attribution
  * 361002__projectsu012__forcefieldcut-chiptone.wav
    * url: https://www.freesound.org/s/361002/
    * license: Attribution
  * 361001__projectsu012__gameover1-chiptone.wav
    * url: https://www.freesound.org/s/361001/
    * license: Attribution
  * 361000__projectsu012__glitch2-chiptone.wav
    * url: https://www.freesound.org/s/361000/
    * license: Attribution
  * 360999__projectsu012__overlapping-waveforms.wav
    * url: https://www.freesound.org/s/360999/
    * license: Attribution
  * 360998__projectsu012__outdoorlawnmachine1-sfxr.wav
    * url: https://www.freesound.org/s/360998/
    * license: Attribution
  * 360997__projectsu012__noisytone1-chiptone.wav
    * url: https://www.freesound.org/s/360997/
    * license: Attribution
  * 360996__projectsu012__noisysqueak1.wav
    * url: https://www.freesound.org/s/360996/
    * license: Attribution
  * 360995__projectsu012__grappling1-chiptone.wav
    * url: https://www.freesound.org/s/360995/
    * license: Attribution
  * 360994__projectsu012__gunfire1-sfxr.wav
    * url: https://www.freesound.org/s/360994/
    * license: Attribution
  * 360993__projectsu012__pluckingcontinue1-chiptone.wav
    * url: https://www.freesound.org/s/360993/
    * license: Attribution
  * 360992__projectsu012__piston-move-chiptone.wav
    * url: https://www.freesound.org/s/360992/
    * license: Attribution
  * 360991__projectsu012__wavynoise-chiptone.wav
    * url: https://www.freesound.org/s/360991/
    * license: Attribution
  * 360990__projectsu012__up1-chiptone.wav
    * url: https://www.freesound.org/s/360990/
    * license: Attribution
  * 360989__projectsu012__relayrelease1-chiptone.wav
    * url: https://www.freesound.org/s/360989/
    * license: Attribution
  * 360988__projectsu012__sndlasershoot1-chiptone.wav
    * url: https://www.freesound.org/s/360988/
    * license: Attribution
  * 360987__projectsu012__explosion2-labchirp.wav
    * url: https://www.freesound.org/s/360987/
    * license: Attribution
  * 360986__projectsu012__explosion1-chiptone.wav
    * url: https://www.freesound.org/s/360986/
    * license: Attribution
  * 360985__projectsu012__explodeanddown.wav
    * url: https://www.freesound.org/s/360985/
    * license: Attribution
  * 360984__projectsu012__expl2-chiptone.wav
    * url: https://www.freesound.org/s/360984/
    * license: Attribution
  * 360983__projectsu012__finished1-chiptone.wav
    * url: https://www.freesound.org/s/360983/
    * license: Attribution
  * 360982__projectsu012__explosion8-chiptone.wav
    * url: https://www.freesound.org/s/360982/
    * license: Attribution
  * 360981__projectsu012__explosion7-chiptone.wav
    * url: https://www.freesound.org/s/360981/
    * license: Attribution
  * 360980__projectsu012__explosion6.wav
    * url: https://www.freesound.org/s/360980/
    * license: Attribution
  * 360979__projectsu012__powerdown1-chiptone.wav
    * url: https://www.freesound.org/s/360979/
    * license: Attribution
  * 360978__projectsu012__powerup-chiptone.wav
    * url: https://www.freesound.org/s/360978/
    * license: Attribution
  * 360977__projectsu012__flapping1-chiptone.wav
    * url: https://www.freesound.org/s/360977/
    * license: Attribution
  * 360976__projectsu012__flamethrower-loop1-chiptone.wav
    * url: https://www.freesound.org/s/360976/
    * license: Attribution
  * 360975__projectsu012__quickringing1-chiptone.wav
    * url: https://www.freesound.org/s/360975/
    * license: Attribution
  * 360974__projectsu012__raining1-chiptone.wav
    * url: https://www.freesound.org/s/360974/
    * license: Attribution
  * 360973__projectsu012__rattlingtremor1-chiptone.wav
    * url: https://www.freesound.org/s/360973/
    * license: Attribution
  * 360972__projectsu012__ray1-chiptone.wav
    * url: https://www.freesound.org/s/360972/
    * license: Attribution
  * 360971__projectsu012__charginghiss1-sfxr.wav
    * url: https://www.freesound.org/s/360971/
    * license: Attribution
  * 360970__projectsu012__chargingkickin1-chiptone.wav
    * url: https://www.freesound.org/s/360970/
    * license: Attribution
  * 360969__projectsu012__charging4-chiptone.wav
    * url: https://www.freesound.org/s/360969/
    * license: Attribution
  * 360968__projectsu012__chargingblip1-sfxr.wav
    * url: https://www.freesound.org/s/360968/
    * license: Attribution
  * 360967__projectsu012__charging2-chiptone.wav
    * url: https://www.freesound.org/s/360967/
    * license: Attribution
  * 360966__projectsu012__charging3-chiptone.wav
    * url: https://www.freesound.org/s/360966/
    * license: Attribution
  * 360965__projectsu012__chargeup1-chiptone.wav
    * url: https://www.freesound.org/s/360965/
    * license: Attribution
  * 360964__projectsu012__chargeuplong1-chiptone.wav
    * url: https://www.freesound.org/s/360964/
    * license: Attribution
  * 360963__projectsu012__charginglaunch1-chiptone.wav
    * url: https://www.freesound.org/s/360963/
    * license: Attribution
  * 360962__projectsu012__chargingsqueak1-chiptone.wav
    * url: https://www.freesound.org/s/360962/
    * license: Attribution
  * 360961__projectsu012__whish1-sfxr.wav
    * url: https://www.freesound.org/s/360961/
    * license: Attribution
  * 360960__projectsu012__shoot3-chiptone.wav
    * url: https://www.freesound.org/s/360960/
    * license: Attribution
  * 360959__projectsu012__tearing1-chiptone.wav
    * url: https://www.freesound.org/s/360959/
    * license: Attribution
  * 360958__projectsu012__tumbling1-sfxr.wav
    * url: https://www.freesound.org/s/360958/
    * license: Attribution
  * 360957__projectsu012__vibrating1-sfxr.wav
    * url: https://www.freesound.org/s/360957/
    * license: Attribution
  * 360956__projectsu012__upnoisy1-chiptone.wav
    * url: https://www.freesound.org/s/360956/
    * license: Attribution
  * 360955__projectsu012__masexplp4-chiptone.wav
    * url: https://www.freesound.org/s/360955/
    * license: Attribution
  * 360954__projectsu012__teleporter1.wav
    * url: https://www.freesound.org/s/360954/
    * license: Attribution
  * 360953__projectsu012__trianglelaser1-chiptone.wav
    * url: https://www.freesound.org/s/360953/
    * license: Attribution
  * 360952__projectsu012__masexplp1-chiptone.wav
    * url: https://www.freesound.org/s/360952/
    * license: Attribution
  * 360951__projectsu012__masexpl-chiptone.wav
    * url: https://www.freesound.org/s/360951/
    * license: Attribution
  * 360950__projectsu012__masexplp3.wav
    * url: https://www.freesound.org/s/360950/
    * license: Attribution
  * 360932__projectsu012__masexplp2-chiptone.wav
    * url: https://www.freesound.org/s/360932/
    * license: Attribution
  * 360931__projectsu012__longlaunch1.wav
    * url: https://www.freesound.org/s/360931/
    * license: Attribution
  * 360930__projectsu012__longlaser1.wav
    * url: https://www.freesound.org/s/360930/
    * license: Attribution
  * 360929__projectsu012__lowresringing-chiptone.wav
    * url: https://www.freesound.org/s/360929/
    * license: Attribution
  * 360928__projectsu012__lotom-sfxr.wav
    * url: https://www.freesound.org/s/360928/
    * license: Attribution
  * 360927__projectsu012__breaking1-chiptone.wav
    * url: https://www.freesound.org/s/360927/
    * license: Attribution
  * 360926__projectsu012__bouncelow-chiptone.wav
    * url: https://www.freesound.org/s/360926/
    * license: Attribution
  * 360925__projectsu012__buzz-working1-chiptone.wav
    * url: https://www.freesound.org/s/360925/
    * license: Attribution
  * 360924__projectsu012__buildup1-chiptone.wav
    * url: https://www.freesound.org/s/360924/
    * license: Attribution
  * 360923__projectsu012__bossbg1-chiptone.wav
    * url: https://www.freesound.org/s/360923/
    * license: Attribution
  * 360921__projectsu012__boss-stop-chiptone.wav
    * url: https://www.freesound.org/s/360921/
    * license: Attribution
  * 360920__projectsu012__bossdest1a-chiptone.wav
    * url: https://www.freesound.org/s/360920/
    * license: Attribution
  * 360919__projectsu012__bossdest1-chiptone.wav
    * url: https://www.freesound.org/s/360919/
    * license: Attribution
  * 360918__projectsu012__shoot2-chiptone.wav
    * url: https://www.freesound.org/s/360918/
    * license: Attribution
  * 360917__projectsu012__shoot1.wav
    * url: https://www.freesound.org/s/360917/
    * license: Attribution
  * 360916__projectsu012__shoot1-chiptone.wav
    * url: https://www.freesound.org/s/360916/
    * license: Attribution
  * 360915__projectsu012__shiplosspart1.wav
    * url: https://www.freesound.org/s/360915/
    * license: Attribution
  * 360914__projectsu012__buzzsus-chiptone.wav
    * url: https://www.freesound.org/s/360914/
    * license: Attribution
  * 360913__projectsu012__buzzring1-chiptone.wav
    * url: https://www.freesound.org/s/360913/
    * license: Attribution
  * 360912__projectsu012__shipdestpart2-chiptone.wav
    * url: https://www.freesound.org/s/360912/
    * license: Attribution
  * 360879__projectsu012__shipdestpart1-chiptone.wav
    * url: https://www.freesound.org/s/360879/
    * license: Attribution
  * 360878__projectsu012__zappinglaser1-chiptone.wav
    * url: https://www.freesound.org/s/360878/
    * license: Attribution
  * 360877__projectsu012__tonalexplosion.wav
    * url: https://www.freesound.org/s/360877/
    * license: Attribution
  * 360876__projectsu012__towerdest1-chiptone.wav
    * url: https://www.freesound.org/s/360876/
    * license: Attribution
  * 360875__projectsu012__teleporter2.wav
    * url: https://www.freesound.org/s/360875/
    * license: Attribution
  * 360874__projectsu012__temp.wav
    * url: https://www.freesound.org/s/360874/
    * license: Attribution
  * 360873__projectsu012__noisy.wav
    * url: https://www.freesound.org/s/360873/
    * license: Attribution
  * 360872__projectsu012__noisylaser1-chiptone.wav
    * url: https://www.freesound.org/s/360872/
    * license: Attribution
  * 360871__projectsu012__timpani1-chiptone.wav
    * url: https://www.freesound.org/s/360871/
    * license: Attribution
  * 360870__projectsu012__ting1.wav
    * url: https://www.freesound.org/s/360870/
    * license: Attribution
  * 360869__projectsu012__ticking1-chiptone.wav
    * url: https://www.freesound.org/s/360869/
    * license: Attribution
  * 360868__projectsu012__tightsqueaking1-chiptone.wav
    * url: https://www.freesound.org/s/360868/
    * license: Attribution
  * 360867__projectsu012__modulatesawbuzz1-chiptone.wav
    * url: https://www.freesound.org/s/360867/
    * license: Attribution
  * 360866__projectsu012__moving1.wav
    * url: https://www.freesound.org/s/360866/
    * license: Attribution
  * 360865__projectsu012__metalliccharge1-chiptone.wav
    * url: https://www.freesound.org/s/360865/
    * license: Attribution
  * 360864__projectsu012__midtom-sfxr.wav
    * url: https://www.freesound.org/s/360864/
    * license: Attribution
  * 360863__projectsu012__noiseandtriangle1-chiptone.wav
    * url: https://www.freesound.org/s/360863/
    * license: Attribution
  * 360862__projectsu012__noisecrunching-as3sfxr.wav
    * url: https://www.freesound.org/s/360862/
    * license: Attribution
  * 360861__projectsu012__moving1a.wav
    * url: https://www.freesound.org/s/360861/
    * license: Attribution
  * 360860__projectsu012__mystic1.wav
    * url: https://www.freesound.org/s/360860/
    * license: Attribution
  * 347809__projectsu012__razor-like-synth.wav
    * url: https://www.freesound.org/s/347809/
    * license: Attribution
  * 341708__projectsu012__bouncing-3.wav
    * url: https://www.freesound.org/s/341708/
    * license: Attribution
  * 341707__projectsu012__water-pounding.wav
    * url: https://www.freesound.org/s/341707/
    * license: Attribution
  * 341706__projectsu012__bobbing-square-wave-vibrato.wav
    * url: https://www.freesound.org/s/341706/
    * license: Attribution
  * 341705__projectsu012__high-tapping-and-sustain.wav
    * url: https://www.freesound.org/s/341705/
    * license: Attribution
  * 341704__projectsu012__low-tone-tapping.wav
    * url: https://www.freesound.org/s/341704/
    * license: Attribution
  * 341703__projectsu012__squeaking-target-hit.wav
    * url: https://www.freesound.org/s/341703/
    * license: Attribution
  * 341702__projectsu012__explosion-with-weaker-repetitions.wav
    * url: https://www.freesound.org/s/341702/
    * license: Attribution
  * 341701__projectsu012__shmup-player-explosion.mp3
    * url: https://www.freesound.org/s/341701/
    * license: Attribution
  * 341700__projectsu012__whirling-buzzes.wav
    * url: https://www.freesound.org/s/341700/
    * license: Attribution
  * 341699__projectsu012__descent-with-buzzes-per-bounce.wav
    * url: https://www.freesound.org/s/341699/
    * license: Attribution
  * 341697__projectsu012__peow-saw-sound.wav
    * url: https://www.freesound.org/s/341697/
    * license: Attribution
  * 341696__projectsu012__louder-pewing-sound.wav
    * url: https://www.freesound.org/s/341696/
    * license: Attribution
  * 341695__projectsu012__coins-1.wav
    * url: https://www.freesound.org/s/341695/
    * license: Attribution
  * 341694__projectsu012__loud-short-release-explosion.wav
    * url: https://www.freesound.org/s/341694/
    * license: Attribution
  * 341693__projectsu012__changing-sweeping-noise.wav
    * url: https://www.freesound.org/s/341693/
    * license: Attribution
  * 341692__projectsu012__noisycrackling1-bfxr.wav
    * url: https://www.freesound.org/s/341692/
    * license: Attribution
  * 341691__projectsu012__longer-noise-driving-upwards.wav
    * url: https://www.freesound.org/s/341691/
    * license: Attribution
  * 341690__projectsu012__descending-chirp-with-delay-effect.wav
    * url: https://www.freesound.org/s/341690/
    * license: Attribution
  * 341689__projectsu012__quiet-low-ringing.wav
    * url: https://www.freesound.org/s/341689/
    * license: Attribution
  * 341688__projectsu012__space-machine-1.wav
    * url: https://www.freesound.org/s/341688/
    * license: Attribution
  * 341662__projectsu012__buzzing-and-background-descent.wav
    * url: https://www.freesound.org/s/341662/
    * license: Attribution
  * 341661__projectsu012__advancing-level.wav
    * url: https://www.freesound.org/s/341661/
    * license: Attribution
  * 341660__projectsu012__dropping-and-buzzing-shorter.wav
    * url: https://www.freesound.org/s/341660/
    * license: Attribution
  * 341659__projectsu012__sawtooth-wave-move-effect.wav
    * url: https://www.freesound.org/s/341659/
    * license: Attribution
  * 341658__projectsu012__trill-powering.wav
    * url: https://www.freesound.org/s/341658/
    * license: Attribution
  * 341657__projectsu012__slide-ping.wav
    * url: https://www.freesound.org/s/341657/
    * license: Attribution
  * 341656__projectsu012__descending-1.wav
    * url: https://www.freesound.org/s/341656/
    * license: Attribution
  * 341655__projectsu012__distancing-power.wav
    * url: https://www.freesound.org/s/341655/
    * license: Attribution
  * 341654__projectsu012__slow-tapping-and-blowing-or-slower-running-steps.wav
    * url: https://www.freesound.org/s/341654/
    * license: Attribution
  * 341653__projectsu012__dropping-and-buzzing.wav
    * url: https://www.freesound.org/s/341653/
    * license: Attribution
  * 341629__projectsu012__coin-insert-or-collecting-item.wav
    * url: https://www.freesound.org/s/341629/
    * license: Attribution
  * 341628__projectsu012__noise-driving-upwards.wav
    * url: https://www.freesound.org/s/341628/
    * license: Attribution
  * 341627__projectsu012__fast-paced-achievement.wav
    * url: https://www.freesound.org/s/341627/
    * license: Attribution
  * 341626__projectsu012__small-boom.wav
    * url: https://www.freesound.org/s/341626/
    * license: Attribution
  * 341625__projectsu012__rpg-game-move-charging-or-application-2.wav
    * url: https://www.freesound.org/s/341625/
    * license: Attribution
  * 341624__projectsu012__rpg-game-move-charging-or-application-2-square.wav
    * url: https://www.freesound.org/s/341624/
    * license: Attribution
  * 341623__projectsu012__vibrato-ish-explosion.wav
    * url: https://www.freesound.org/s/341623/
    * license: Attribution
  * 341621__projectsu012__high-short-alarm.wav
    * url: https://www.freesound.org/s/341621/
    * license: Attribution
  * 341620__projectsu012__arpeggiating-delay-ringing.wav
    * url: https://www.freesound.org/s/341620/
    * license: Attribution
  * 341030__projectsu012__counting-pinball-bonus-blip.wav
    * url: https://www.freesound.org/s/341030/
    * license: Attribution
  * 341029__projectsu012__short-buzz.wav
    * url: https://www.freesound.org/s/341029/
    * license: Attribution
  * 341028__projectsu012__crackling-low-buzzes.wav
    * url: https://www.freesound.org/s/341028/
    * license: Attribution
  * 341027__projectsu012__quick-burst.wav
    * url: https://www.freesound.org/s/341027/
    * license: Attribution
  * 341026__projectsu012__high-metallic-pounding.wav
    * url: https://www.freesound.org/s/341026/
    * license: Attribution
  * 341025__projectsu012__short-square-trip.wav
    * url: https://www.freesound.org/s/341025/
    * license: Attribution
  * 341024__projectsu012__blip-2.wav
    * url: https://www.freesound.org/s/341024/
    * license: Attribution
  * 341023__projectsu012__noise-zap.wav
    * url: https://www.freesound.org/s/341023/
    * license: Attribution
  * 341022__projectsu012__spraying-sprinklers.wav
    * url: https://www.freesound.org/s/341022/
    * license: Attribution
  * 340982__projectsu012__zap-bonus.wav
    * url: https://www.freesound.org/s/340982/
    * license: Attribution
  * 340981__projectsu012__lower-ringing.wav
    * url: https://www.freesound.org/s/340981/
    * license: Attribution
  * 340980__projectsu012__squeaky-sweep.wav
    * url: https://www.freesound.org/s/340980/
    * license: Attribution
  * 340978__projectsu012__hiss-then-sizzle.wav
    * url: https://www.freesound.org/s/340978/
    * license: Attribution
  * 340977__projectsu012__tumble-knocking.wav
    * url: https://www.freesound.org/s/340977/
    * license: Attribution
  * 340976__projectsu012__hissing-static-noise.wav
    * url: https://www.freesound.org/s/340976/
    * license: Attribution
  * 340975__projectsu012__shorter-crackle.wav
    * url: https://www.freesound.org/s/340975/
    * license: Attribution
  * 340974__projectsu012__computer-processing-data.wav
    * url: https://www.freesound.org/s/340974/
    * license: Attribution
  * 340973__projectsu012__short-repetitive-explosion.wav
    * url: https://www.freesound.org/s/340973/
    * license: Attribution
  * 340961__projectsu012__crackling.wav
    * url: https://www.freesound.org/s/340961/
    * license: Attribution
  * 340960__projectsu012__sizzling-boom.wav
    * url: https://www.freesound.org/s/340960/
    * license: Attribution
  * 340959__projectsu012__scanning-sound.wav
    * url: https://www.freesound.org/s/340959/
    * license: Attribution
  * 340958__projectsu012__robot-mechanics.wav
    * url: https://www.freesound.org/s/340958/
    * license: Attribution
  * 340957__projectsu012__loud-ringing.wav
    * url: https://www.freesound.org/s/340957/
    * license: Attribution
  * 340956__projectsu012__rocket-short.wav
    * url: https://www.freesound.org/s/340956/
    * license: Attribution
  * 340955__projectsu012__ringing-laser-low.wav
    * url: https://www.freesound.org/s/340955/
    * license: Attribution
  * 340954__projectsu012__loud-pitch-ducking.wav
    * url: https://www.freesound.org/s/340954/
    * license: Attribution
  * 340953__projectsu012__rattling-crackling.wav
    * url: https://www.freesound.org/s/340953/
    * license: Attribution
  * 340952__projectsu012__tap-tap-tap-tap-tap.wav
    * url: https://www.freesound.org/s/340952/
    * license: Attribution
  * 340950__projectsu012__constantly-switching-alarm.wav
    * url: https://www.freesound.org/s/340950/
    * license: Attribution
  * 340949__projectsu012__triangle-wave-ringing.wav
    * url: https://www.freesound.org/s/340949/
    * license: Attribution
  * 340948__projectsu012__alarm-deep-sawtooth.wav
    * url: https://www.freesound.org/s/340948/
    * license: Attribution
  * 340947__projectsu012__alarm-deep-square.wav
    * url: https://www.freesound.org/s/340947/
    * license: Attribution
  * 340946__projectsu012__beep-beep-beep-beep-beep-beep.wav
    * url: https://www.freesound.org/s/340946/
    * license: Attribution
  * 340945__projectsu012__sliding-alert.wav
    * url: https://www.freesound.org/s/340945/
    * license: Attribution
  * 340944__projectsu012__failure-square-wave.wav
    * url: https://www.freesound.org/s/340944/
    * license: Attribution
  * 340943__projectsu012__activate-ringing.wav
    * url: https://www.freesound.org/s/340943/
    * license: Attribution
  * 340942__projectsu012__square-alarm.wav
    * url: https://www.freesound.org/s/340942/
    * license: Attribution
  * 340941__projectsu012__alarming-saw-wave.wav
    * url: https://www.freesound.org/s/340941/
    * license: Attribution
  * 337269__projectsu012__quiet-ringing-and-attack.wav
    * url: https://www.freesound.org/s/337269/
    * license: Attribution
  * 337268__projectsu012__swish-crunch.wav
    * url: https://www.freesound.org/s/337268/
    * license: Attribution
  * 337267__projectsu012__tremolo-ringing.wav
    * url: https://www.freesound.org/s/337267/
    * license: Attribution
  * 337266__projectsu012__power-charging.wav
    * url: https://www.freesound.org/s/337266/
    * license: Attribution
  * 337265__projectsu012__ringing3-chiptone.wav
    * url: https://www.freesound.org/s/337265/
    * license: Attribution
  * 337264__projectsu012__dropping-echo-longer.wav
    * url: https://www.freesound.org/s/337264/
    * license: Attribution
  * 337263__projectsu012__laser.wav
    * url: https://www.freesound.org/s/337263/
    * license: Attribution
  * 337262__projectsu012__metallic-ringing.wav
    * url: https://www.freesound.org/s/337262/
    * license: Attribution
  * 337261__projectsu012__reverbing-echo.wav
    * url: https://www.freesound.org/s/337261/
    * license: Attribution
  * 337260__projectsu012__sprinklers-1.wav
    * url: https://www.freesound.org/s/337260/
    * license: Attribution
  * 337259__projectsu012__quiet-vroom-sound.wav
    * url: https://www.freesound.org/s/337259/
    * license: Attribution
  * 337258__projectsu012__small-tumbling.wav
    * url: https://www.freesound.org/s/337258/
    * license: Attribution
  * 337257__projectsu012__alert-alert-alert.wav
    * url: https://www.freesound.org/s/337257/
    * license: Attribution
  * 337256__projectsu012__percussive-sweeping.wav
    * url: https://www.freesound.org/s/337256/
    * license: Attribution
  * 337255__projectsu012__speed-ringing.wav
    * url: https://www.freesound.org/s/337255/
    * license: Attribution
  * 337254__projectsu012__tone-ring-down.wav
    * url: https://www.freesound.org/s/337254/
    * license: Attribution
  * 337253__projectsu012__swishing.wav
    * url: https://www.freesound.org/s/337253/
    * license: Attribution
  * 337252__projectsu012__slow-falling.wav
    * url: https://www.freesound.org/s/337252/
    * license: Attribution
  * 337251__projectsu012__helicopter-passing-by.wav
    * url: https://www.freesound.org/s/337251/
    * license: Attribution
  * 337250__projectsu012__laser-chirping.wav
    * url: https://www.freesound.org/s/337250/
    * license: Attribution
  * 337249__projectsu012__futuristic-computer-room-ambience.wav
    * url: https://www.freesound.org/s/337249/
    * license: Attribution
  * 337248__projectsu012__vehicle-scene.wav
    * url: https://www.freesound.org/s/337248/
    * license: Attribution
  * 337247__projectsu012__outlane.wav
    * url: https://www.freesound.org/s/337247/
    * license: Attribution
  * 337246__projectsu012__activation-or-achievement-1.wav
    * url: https://www.freesound.org/s/337246/
    * license: Attribution
  * 337245__projectsu012__arpeggiating-1.wav
    * url: https://www.freesound.org/s/337245/
    * license: Attribution
  * 337244__projectsu012__happy-bonus-score.wav
    * url: https://www.freesound.org/s/337244/
    * license: Attribution
  * 337243__projectsu012__bonus-score-1.wav
    * url: https://www.freesound.org/s/337243/
    * license: Attribution
  * 334287__projectsu012__swoosh-2.wav
    * url: https://www.freesound.org/s/334287/
    * license: Attribution
  * 334286__projectsu012__power-target.wav
    * url: https://www.freesound.org/s/334286/
    * license: Attribution
  * 334285__projectsu012__repetitive-tapping.wav
    * url: https://www.freesound.org/s/334285/
    * license: Attribution
  * 334284__projectsu012__whirring.wav
    * url: https://www.freesound.org/s/334284/
    * license: Attribution
  * 334283__projectsu012__slow-helicopter-sweeping.wav
    * url: https://www.freesound.org/s/334283/
    * license: Attribution
  * 334282__projectsu012__weird-power-1.wav
    * url: https://www.freesound.org/s/334282/
    * license: Attribution
  * 334281__projectsu012__rocket1.wav
    * url: https://www.freesound.org/s/334281/
    * license: Attribution
  * 334280__projectsu012__rocket-2.wav
    * url: https://www.freesound.org/s/334280/
    * license: Attribution
  * 334279__projectsu012__machine-gun.wav
    * url: https://www.freesound.org/s/334279/
    * license: Attribution
  * 334278__projectsu012__machine-vibration.wav
    * url: https://www.freesound.org/s/334278/
    * license: Attribution
  * 334277__projectsu012__ping-coin.wav
    * url: https://www.freesound.org/s/334277/
    * license: Attribution
  * 334276__projectsu012__power-down.wav
    * url: https://www.freesound.org/s/334276/
    * license: Attribution
  * 334275__projectsu012__powerup-2.wav
    * url: https://www.freesound.org/s/334275/
    * license: Attribution
  * 334274__projectsu012__target-complete.wav
    * url: https://www.freesound.org/s/334274/
    * license: Attribution
  * 334273__projectsu012__metalic-ringing.wav
    * url: https://www.freesound.org/s/334273/
    * license: Attribution
  * 334272__projectsu012__grunge-noise.wav
    * url: https://www.freesound.org/s/334272/
    * license: Attribution
  * 334271__projectsu012__fading-in-pews.wav
    * url: https://www.freesound.org/s/334271/
    * license: Attribution
  * 334270__projectsu012__pews-2.wav
    * url: https://www.freesound.org/s/334270/
    * license: Attribution
  * 334269__projectsu012__launching-2.wav
    * url: https://www.freesound.org/s/334269/
    * license: Attribution
  * 334268__projectsu012__launching-1.wav
    * url: https://www.freesound.org/s/334268/
    * license: Attribution
  * 334267__projectsu012__balloon-deflating-1.wav
    * url: https://www.freesound.org/s/334267/
    * license: Attribution
  * 334266__projectsu012__short-explosion-1.wav
    * url: https://www.freesound.org/s/334266/
    * license: Attribution
  * 334265__projectsu012__tremolo-explosion.wav
    * url: https://www.freesound.org/s/334265/
    * license: Attribution
  * 334264__projectsu012__inflating.wav
    * url: https://www.freesound.org/s/334264/
    * license: Attribution
  * 334263__projectsu012__powerup-sound-1.wav
    * url: https://www.freesound.org/s/334263/
    * license: Attribution
  * 334262__projectsu012__explosive-bang.wav
    * url: https://www.freesound.org/s/334262/
    * license: Attribution
  * 334261__projectsu012__coin-chime.wav
    * url: https://www.freesound.org/s/334261/
    * license: Attribution
  * 334260__projectsu012__crackling-et-explosion.wav
    * url: https://www.freesound.org/s/334260/
    * license: Attribution
  * 333786__projectsu012__8-bit-pitch-sweeping-effect.wav
    * url: https://www.freesound.org/s/333786/
    * license: Attribution
  * 333785__projectsu012__8-bit-failure-sound.wav
    * url: https://www.freesound.org/s/333785/
    * license: Attribution
  * 333784__projectsu012__8-bit-few-pew-effects.wav
    * url: https://www.freesound.org/s/333784/
    * license: Attribution
  * 333783__projectsu012__pitch-sliding-down-and-back-up-8-bit.wav
    * url: https://www.freesound.org/s/333783/
    * license: Attribution
  * 333782__projectsu012__8-bit-pitch-descalation-effect.wav
    * url: https://www.freesound.org/s/333782/
    * license: Attribution
  * 333691__projectsu012__8-bit-pew-i.wav
    * url: https://www.freesound.org/s/333691/
    * license: Attribution

